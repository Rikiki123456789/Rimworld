﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using UnityEngine;   // Always needed
using RimWorld;      // RimWorld specific functions are found here
using Verse;         // RimWorld universal objects are here
//using Verse.AI;    // Needed when you do something with the AI
using Verse.Sound;   // Needed when you do something with the Sound

namespace MiningTurret
{
    /// <summary>
    /// Building_MiningTurret class.
    /// </summary>
    /// <author>Rikiki</author>
    /// <permission>Use this code as you want, just remember to add a link to the corresponding Ludeon forum mod release thread.
    /// Remember learning is always better than just copy/paste...</permission>
    [StaticConstructorOnStartup]
    class Building_MiningTurret : Building
    {
        // TODO: copy constructMetal effecter => remove sound?
        // Remove saw ambient sound.
        // Set white line bolder.
        // TODO: add a man component? excepted non miners.
        //     and thus workgiver.
        // TODO: add a research to automate it?

        public enum MiningMode
        {
            Ores,
            Rocks,
            OresAndRocks
        }
        
        // ===================== Variables =====================
        public const int updatePeriodInTicks = 30;//GenTicks.TicksPerRealSecond; //TODO: adjust value.
        public int updateOffsetInTicks = 0;

        // Components references.
        public CompPowerTrader powerComp;
        
        public const int drillRateInTicks = 5;
        public IntVec3 targetPosition = IntVec3.Invalid;        
        public MiningMode miningMode = MiningMode.Ores;

        // Rotation.
        public const int turretTopRotationRateInTicks = 4; // Rate at which rotation is changed by 1°.
        public float turretTopRotation = 0f;
        public float turretTopRotationTarget = 0f;
        public bool turretTopRotationTurnRight = true;

        // Sound.
        public Sustainer laserDrillSoundSustainer = null;

        // Effecter.
        public Effecter laserDrillEffecter = null;

        // Textures.
        public static Material turretTopOnTexture = MaterialPool.MatFrom("Things/Building/MiningTurret_On");
        public static Material turretTopOffTexture = MaterialPool.MatFrom("Things/Building/MiningTurret_Off");
        public Matrix4x4 turretTopMatrix = default(Matrix4x4);
        public Vector3 turretTopScale = new Vector3(4f, 1f, 4f);
        public Matrix4x4 laserBeamMatrix = default(Matrix4x4);
        public Vector3 laserBeamScale = new Vector3(1f, 1f, 1f);
        public static Material laserBeamTexture = MaterialPool.MatFrom("Effects/MiningTurret_LaserBeam", ShaderDatabase.Transparent);
        public static Material targetLineTexture = MaterialPool.MatFrom(GenDraw.LineTexPath, ShaderDatabase.Transparent, new Color(1f, 1f, 1f));

        // ===================== Setup Work =====================
        /// <summary>
        /// Initialize instance variables.
        /// </summary>
        public override void SpawnSetup(Map map, bool respawningAfterLoad)
        {
            base.SpawnSetup(map, respawningAfterLoad);

            this.powerComp = base.GetComp<CompPowerTrader>();
            this.updateOffsetInTicks = Rand.RangeInclusive(0, updatePeriodInTicks);

            turretTopMatrix.SetTRS(base.DrawPos + Altitudes.AltIncVect, this.turretTopRotation.ToQuat(), turretTopScale);
        }

        /// <summary>
        /// Initialize instance variables.
        /// </summary>
        public override void Destroy(DestroyMode mode = DestroyMode.Vanish)
        {
            base.Destroy(mode);
        }

        /// <summary>
        /// Save and load internal state variables (stored in savegame data).
        /// </summary>
        public override void ExposeData()
        {
            base.ExposeData();

            Scribe_Values.Look<IntVec3>(ref this.targetPosition, "targetPosition");
            Scribe_Values.Look<MiningMode>(ref this.miningMode, "MiningMode");
            Scribe_Values.Look<float>(ref this.turretTopRotation, "turretTopRotation");
            Scribe_Values.Look<float>(ref this.turretTopRotationTarget, "turretTopRotationTarget");
            Scribe_Values.Look<bool>(ref this.turretTopRotationTurnRight, "turretTopRotationTurnRight");
        }

        // ===================== Main Work Function =====================
        /// <summary>
        /// Main function:
        /// - look for a target,
        /// - rotate turret top if needed,
        /// - mine it.
        /// </summary>
        public override void Tick()
        {
            base.Tick();

            // Check if turret is powered.
            if (powerComp.PowerOn == false)
            {
                this.targetPosition = IntVec3.Invalid;
                StopLaserDrillEffecter();
                StopLaserDrillSoundSustainer();
                return;
            }

            if ((Find.TickManager.TicksGame + this.updateOffsetInTicks) % updatePeriodInTicks == 0)
            {
                // Check locked target is still valid.
                if (this.targetPosition.IsValid)
                {
                    if (IsValidTargetAt(this.targetPosition) == false)
                    {
                        // Target is no more valid.
                        this.targetPosition = IntVec3.Invalid;
                        StopLaserDrillEffecter();
                        StopLaserDrillSoundSustainer();
                    }
                }

                // Target is invalid. Look for a valid one.
                if (this.targetPosition.IsValid == false)
                {
                    this.targetPosition = LookForNewTarget();
                    if (this.targetPosition.IsValid)
                    {
                        SoundDefOf.TurretAcquireTarget.PlayOneShot(new TargetInfo(this.Position, this.Map));
                        this.turretTopRotationTarget = Mathf.Repeat(Mathf.Round((this.targetPosition.ToVector3Shifted() - this.TrueCenter()).AngleFlat()), 360f);
                        ComputeRotationDirection();
                    }
                }
            }

            if (this.targetPosition.IsValid)
            {
                // Rotate turret top or drill.
                TurretTopTick();
                if (this.turretTopRotation == this.turretTopRotationTarget)
                {
                    StartOrMaintainLaserDrillEffecter();
                    //StartOrMaintainLaserSound();
                }
                else
                {
                    StopLaserDrillEffecter();
                    StopLaserDrillSoundSustainer();
                }

            }

            ComputeDrawingParameters();
        }

        // ===================== Utility Function =====================
        /// <summary>
        /// Look for a valid target to mine: ore deposit or natural wall to mine within direct line of sight.
        /// </summary>
        public IntVec3 LookForNewTarget()
        {
            IntVec3 newTargetPos = IntVec3.Invalid;
            float minimalDistance = 9999f;
            
            foreach (IntVec3 cell in GenRadial.RadialCellsAround(this.Position, this.def.specialDisplayRadius, false))
            {
                if (IsValidTargetAt(cell))
                {
                    float distance = (cell.ToVector3Shifted() - this.Position.ToVector3Shifted()).magnitude;
                    if (distance < minimalDistance)
                    {
                        minimalDistance = distance;
                        newTargetPos = cell;
                    }
                }
            }
            return newTargetPos;
        }

        /// <summary>
        /// Check if a cell contain a valid target to drill.
        /// </summary>
        public bool IsValidTargetAt(IntVec3 position)
        {
            if (GenSight.LineOfSight(this.Position, position, this.Map))
            {
                if ((this.miningMode == MiningMode.Ores)
                    || (this.miningMode == MiningMode.OresAndRocks))
                {
                    // Look for valid ore deposit.
                    Building oreDeposit = position.GetEdifice(this.Map);
                    if ((oreDeposit != null)
                        && oreDeposit.def.building.isResourceRock
                        && oreDeposit.def.mineable)
                    {
                        return true;
                    }
                }

                if ((this.miningMode == MiningMode.Rocks)
                    || (this.miningMode == MiningMode.OresAndRocks))
                {
                    // Look for valid designation.
                    Designation mineDesignation = this.Map.designationManager.DesignationAt(position, DesignationDefOf.Mine);
                    if (mineDesignation != null)
                    {
                        return true;
                    }
                }
            }

            return false;
        }

        /// <summary>
        /// Compute the optimal rotation direction.
        /// </summary>
        public void ComputeRotationDirection()
        {
            if (this.turretTopRotationTarget >= this.turretTopRotation)
            {
                float dif = this.turretTopRotationTarget - this.turretTopRotation;
                if (dif <= 180f)
                {
                    this.turretTopRotationTurnRight = true;
                }
                else
                {
                    this.turretTopRotationTurnRight = false;
                }
            }
            else
            {
                float dif = this.turretTopRotation - this.turretTopRotationTarget;
                if (dif <= 180f)
                {
                    this.turretTopRotationTurnRight = false;
                }
                else
                {
                    this.turretTopRotationTurnRight = true;
                }
            }
        }

        /// <summary>
        /// Rotate turret top or drill.
        /// </summary>
        public void TurretTopTick()
        {
            // Update turret top rotation.
            if (this.turretTopRotation != this.turretTopRotationTarget)
            {
                if ((Find.TickManager.TicksGame % turretTopRotationRateInTicks) == 0)
                {
                    if (this.turretTopRotationTurnRight)
                    {
                        this.turretTopRotation = Mathf.Repeat(this.turretTopRotation + 1f, 360f);
                    }
                    else
                    {
                        this.turretTopRotation = Mathf.Repeat(this.turretTopRotation - 1f, 360f);
                    }
                }
            }

            // Drill target when correctly rotated.
            if (this.turretTopRotation == this.turretTopRotationTarget)
            {
                Building rock = this.targetPosition.GetEdifice(this.Map);
                if (rock != null)
                {
                    // Drill rock.
                    int drillRate = drillRateInTicks;
                    if (ResearchProjectDef.Named("ResearchMiningTurretEfficientDrilling").IsFinished)
                    {
                        drillRate -= 2;
                    }
                    if (((Find.TickManager.TicksGame + updateOffsetInTicks) % drillRate) == 0)
                    {
                        if (rock.HitPoints > 1)
                        {
                            rock.TakeDamage(new DamageInfo(DamageDefOf.Mining, 1));
                        }
                        else
                        {
                            if (rock.def.building.isResourceRock
                                && (rock.def.building.mineableThing != null))
                            {
                                int oreQuantity = rock.def.building.mineableYield;
                                if (ResearchProjectDef.Named("ResearchMiningTurretEfficientDrilling").IsFinished == false)
                                {
                                    oreQuantity /= 2;
                                    oreQuantity = Math.Max(1, oreQuantity);
                                }
                                Thing ore = ThingMaker.MakeThing(rock.def.building.mineableThing);
                                ore.stackCount = oreQuantity;
                                GenSpawn.Spawn(ore, rock.Position, this.Map);
                                rock.Destroy(DestroyMode.Vanish);
                            }
                            else
                            {
                                rock.Destroy(DestroyMode.KillFinalize);
                            }
                        }
                        if (rock.DestroyedOrNull())
                        {
                            this.targetPosition = IntVec3.Invalid;
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Stop the laser drill sound sustainer.
        /// </summary>
        public void StopLaserDrillSoundSustainer()
        {
            if (this.laserDrillSoundSustainer != null)
            {
                this.laserDrillSoundSustainer.End();
                this.laserDrillSoundSustainer = null;
            }
        }

        /// <summary>
        /// Start or maintain the laser drill sound sustainer.
        /// </summary>
        public void StartOrMaintainLaserDrillSoundSustainer()
        {
            if (this.laserDrillSoundSustainer == null)
            {
                this.laserDrillSoundSustainer = SoundDef.Named("Recipe_MakeWoodPlanks_Electric").TrySpawnSustainer(new TargetInfo(this.Position, this.Map));
            }
            else
            {
                this.laserDrillSoundSustainer.Maintain();
            }
        }

        /// <summary>
        /// Stop the laser drill effecter.
        /// </summary>
        public void StopLaserDrillEffecter()
        {
            if (this.laserDrillEffecter != null)
            {
                this.laserDrillEffecter.Cleanup();
                this.laserDrillEffecter = null;
            }
        }

        /// <summary>
        /// Start or maintain the laser drill effecter.
        /// </summary>
        public void StartOrMaintainLaserDrillEffecter()
        {
            if (this.laserDrillEffecter == null)
            {
                this.laserDrillEffecter = new Effecter(EffecterDef.Named("LaserDrill"));
            }
            else
            {
                this.laserDrillEffecter.EffectTick(new TargetInfo(this.targetPosition, this.Map), new TargetInfo(this.Position, this.Map));
            }
        }

        /// <summary>
        /// Compute the laser beam parameters.
        /// </summary>
        public void ComputeDrawingParameters()
        {
            if (this.targetPosition.IsValid
                && (this.turretTopRotation == this.turretTopRotationTarget))
            {
                Vector3 turretTargetVector = (this.targetPosition.ToVector3Shifted() - this.TrueCenter());
                turretTargetVector.y = 0f;
                this.laserBeamScale.z = turretTargetVector.magnitude - 0.8f;
                Vector3 positionOffset = turretTargetVector / 2f;
                laserBeamMatrix.SetTRS(base.DrawPos + Altitudes.AltIncVect + positionOffset, this.turretTopRotation.ToQuat(), this.laserBeamScale);
            }
            else
            {
                this.laserBeamScale.z = 1.5f;
                Vector3 positionOffset = new Vector3(0f, 0f, this.laserBeamScale.z / 2f).RotatedBy(this.turretTopRotation);
                laserBeamMatrix.SetTRS(base.DrawPos + Altitudes.AltIncVect + positionOffset, this.turretTopRotation.ToQuat(), this.laserBeamScale);
            }
        }

        /// <summary>
        /// Draw the turret top, a laser beam when drilling and a line to the targeted rock.
        /// </summary>
        public override void Draw()
        {
            base.Draw();
            this.turretTopMatrix.SetTRS(base.DrawPos + 1.1f * Altitudes.AltIncVect, this.turretTopRotation.ToQuat(), this.turretTopScale);
            if (this.powerComp.PowerOn)
            {
                Graphics.DrawMesh(MeshPool.plane10, this.turretTopMatrix, turretTopOnTexture, 0);
                Graphics.DrawMesh(MeshPool.plane10, this.laserBeamMatrix, laserBeamTexture, 0);
            }
            else
            {
                Graphics.DrawMesh(MeshPool.plane10, this.turretTopMatrix, turretTopOffTexture, 0);
            }

            if (Find.Selector.IsSelected(this)
                && (this.targetPosition.IsValid))
            {
                Vector3 lineOrigin = this.TrueCenter();
                Vector3 lineTarget = this.targetPosition.ToVector3Shifted();
                lineTarget.y = Altitudes.AltitudeFor(AltitudeLayer.MetaOverlays);
                lineOrigin.y = lineTarget.y;
                GenDraw.DrawLineBetween(lineOrigin, lineTarget, targetLineTexture);
            }
        }

        public override IEnumerable<Gizmo> GetGizmos()
        {
            IList<Gizmo> buttonList = new List<Gizmo>();
            int groupKeyBase = 700000103;

            Command_Action miningModeButton = new Command_Action();
            switch (this.miningMode)
            {
                case (MiningMode.Ores):
                    miningModeButton.defaultLabel = "Mining mode: ores";
                    miningModeButton.defaultDesc = "Mining mode: ores. In this mode, the mining turret automatically drill nearby ores.";
                    break;
                case (MiningMode.OresAndRocks):
                    miningModeButton.defaultLabel = "Mining mode: ores and rocks";
                    miningModeButton.defaultDesc = "Mining mode: ores and rocks. In this mode, the mining turret automatically drill nearby ores and designated rocks.";
                    break;
                case (MiningMode.Rocks):
                    miningModeButton.defaultLabel = "Mining mode: rocks";
                    miningModeButton.defaultDesc = "Mining mode: rocks. In this mode, the mining turret automatically drill nearby designated rocks.";
                    break;
            }
            miningModeButton.icon = ContentFinder<Texture2D>.Get("Ui/Commands/CommandButton_SwitchMode");
            miningModeButton.activateSound = SoundDef.Named("Click");
            miningModeButton.action = new Action(SwitchMiningMode);
            miningModeButton.groupKey = groupKeyBase + 1;
            buttonList.Add(miningModeButton);
            
            Command_Action setTargetButton = new Command_Action();
            setTargetButton.icon = ContentFinder<Texture2D>.Get("UI/Commands/Attack");
            setTargetButton.defaultLabel = "Set target";
            setTargetButton.defaultDesc = "Order the turret to mine a specific rock. Can only target rocks in range with line of sight.";
            setTargetButton.activateSound = SoundDef.Named("Click");
            setTargetButton.action = new Action(SelectTarget);
            setTargetButton.groupKey = groupKeyBase + 6;
            buttonList.Add(setTargetButton);

            IEnumerable<Gizmo> resultButtonList;
            IEnumerable<Gizmo> basebuttonList = base.GetGizmos();
            if (basebuttonList != null)
            {
                resultButtonList = basebuttonList.Concat(buttonList);
            }
            else
            {
                resultButtonList = buttonList;
            }
            return resultButtonList;
        }

        /// <summary>
        /// Switch mining mode.
        /// </summary>
        public void SwitchMiningMode()
        {
            switch (this.miningMode)
            {
                case MiningMode.Ores:
                    this.miningMode = MiningMode.Rocks;
                    break;
                case MiningMode.Rocks:
                    this.miningMode = MiningMode.OresAndRocks;
                    break;
                case MiningMode.OresAndRocks:
                    this.miningMode = MiningMode.Ores;
                    break;
            }
            this.targetPosition = IntVec3.Invalid;
            StopLaserDrillEffecter();
            StopLaserDrillSoundSustainer();
        }

        /// <summary>
        /// Manually select a target to mine.
        /// </summary>
        public void SelectTarget()
        {
            TargetingParameters targetingParams = new TargetingParameters();
            targetingParams.canTargetPawns = false;
            targetingParams.canTargetBuildings = true;
            targetingParams.canTargetLocations = true;
            targetingParams.validator = delegate (TargetInfo targ)
            {
                if (IsValidTargetAt(targ.Cell)
                    && targ.Cell.InHorDistOf(this.Position, this.def.specialDisplayRadius))
                {
                    return true;
                }
                return false;
            };
            Find.Targeter.BeginTargeting(targetingParams, SetForcedTarget);
        }

        public void SetForcedTarget(LocalTargetInfo forcedTarget)
        {
            this.targetPosition = forcedTarget.Cell;
            this.turretTopRotationTarget = Mathf.Repeat(Mathf.Round((this.targetPosition.ToVector3Shifted() - this.Position.ToVector3Shifted()).AngleFlat()), 360f);
            ComputeRotationDirection();
        }
    }
}
